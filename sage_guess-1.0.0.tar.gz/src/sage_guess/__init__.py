__all__ = ['ColorizeString', 'GuessingFormulasForSequences', 'Guess', 
           'SpecialSequences']
